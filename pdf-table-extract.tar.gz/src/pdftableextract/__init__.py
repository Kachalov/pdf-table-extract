# Example package with a console entry point
from core import process_page, output, table_to_list